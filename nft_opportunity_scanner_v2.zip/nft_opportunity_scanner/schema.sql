CREATE TABLE IF NOT EXISTS collections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chain TEXT NOT NULL,
    contract TEXT NOT NULL,
    name TEXT,
    slug TEXT,
    supply INTEGER,
    mint_price_eth REAL,
    mint_start_at TEXT,
    last_mint_at TEXT,
    sold_out_at TEXT,
    max_mint_per_wallet INTEGER,
    ath_floor_usd REAL,
    current_floor_usd REAL,
    last_sale_at TEXT,
    last_sale_price_eth REAL,
    last_sale_price_usd REAL,
    last_sale_token_id TEXT,
    holder_count INTEGER,
    score REAL,
    reasons TEXT,
    source_json TEXT,
    first_seen_at TEXT,
    last_seen_at TEXT,
    alerted_at TEXT,
    UNIQUE(chain, contract)
);

CREATE INDEX IF NOT EXISTS idx_collections_score ON collections(score DESC);
CREATE INDEX IF NOT EXISTS idx_collections_last_sale ON collections(last_sale_at);
CREATE INDEX IF NOT EXISTS idx_collections_sold_out ON collections(sold_out_at);
