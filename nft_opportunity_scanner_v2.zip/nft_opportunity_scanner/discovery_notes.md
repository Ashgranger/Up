# Discovery / storage rules

## Required behavior

1. Enumerate Ethereum NFT collections/contracts.
2. Save every collection, including NOT YET SOLD OUT.
3. Never delete a collection just because it is not sold out.
4. Activity check uses ONLY:
   - last actual sale timestamp
   - last actual sale USD value
5. Do not use:
   - sales in last 24h
   - sales in last 48h
   - rolling volume as an activity gate.

## Discovery

Reservoir's Collections API supports pagination and continuation. Its collection endpoint can expose metadata/statistics, while the Ethereum API provides the Ethereum NFT data layer. citeturn0search1turn0search2

## Last sale

Use the Sales endpoint sorted by time descending with limit 1. The returned sale is the activity record saved to the database. citeturn0search0

## Optional real-time upgrade

Reservoir also documents sale event subscriptions, which can update the saved last-sale record immediately rather than waiting for a polling interval. citeturn0search3
