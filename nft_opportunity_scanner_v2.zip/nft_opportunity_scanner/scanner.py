import argparse
import json
import os
import sqlite3
import time
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

import requests

BASE = os.getenv("RESERVOIR_BASE_URL", "https://api.reservoir.tools")
API_KEY = os.getenv("RESERVOIR_API_KEY", "")
DB_PATH = os.getenv("DB_PATH", "opportunities.db")

MIN_SUPPLY = int(os.getenv("MIN_SUPPLY", "3000"))
MAX_SUPPLY = int(os.getenv("MAX_SUPPLY", "10000"))
MIN_AGE_DAYS = int(os.getenv("MIN_AGE_DAYS", "730"))
MAX_FREE_MINT_ETH = float(os.getenv("MAX_FREE_MINT_ETH", "0"))
MIN_ATH_FLOOR_USD = float(os.getenv("MIN_ATH_FLOOR_USD", "100"))
MIN_MAX_MINT = int(os.getenv("MIN_MAX_MINT", "10"))
ALERT_SCORE = float(os.getenv("ALERT_SCORE", "70"))

session = requests.Session()
session.headers.update({"x-api-key": API_KEY})


def utc_now():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.isoformat().replace("+00:00", "Z")


def parse_ts(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return datetime.fromtimestamp(v, tz=timezone.utc)
    s = str(v).replace("Z", "+00:00")
    try:
        d = datetime.fromisoformat(s)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def get(path, params=None):
    if not API_KEY:
        raise RuntimeError("Set RESERVOIR_API_KEY first.")
    r = session.get(f"{BASE}{path}", params=params or {}, timeout=30)
    r.raise_for_status()
    return r.json()


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.executescript(open("schema.sql", "r", encoding="utf-8").read())


def last_sale_for_collection(contract):
    # Activity is intentionally ONLY the latest actual sale:
    # timestamp + USD sale value. No 24h/48h activity window.
    data = get("/sales/v6", {
        "collection": contract,
        "sortBy": "time",
        "sortDirection": "desc",
        "limit": 1
    })
    sales = data.get("sales", [])
    return sales[0] if sales else None


def collection_snapshot(contract):
    # Collection metadata/stats endpoint. Exact fields can evolve, so the
    # parser below is deliberately defensive.
    return get("/collections/v7", {"id": contract})


def extract_price_usd(sale):
    price = sale.get("price") or {}
    amount = price.get("amount") or {}
    return (
        amount.get("usd") or
        price.get("usd") or
        sale.get("priceUsd")
    )


def extract_price_eth(sale):
    price = sale.get("price") or {}
    amount = price.get("amount") or {}
    return (
        amount.get("native") or
        amount.get("decimal") or
        price.get("amount") or
        sale.get("priceEth")
    )


def normalize_collection(raw):
    # Handles common Reservoir response shapes while preserving raw JSON.
    item = raw
    if isinstance(raw, dict) and raw.get("collections"):
        item = raw["collections"][0]

    return {
        "name": item.get("name"),
        "slug": item.get("slug"),
        "contract": item.get("id") or item.get("primaryContract"),
        "supply": item.get("tokenCount") or item.get("supply"),
        "floor_usd": (
            (item.get("floorAsk") or {}).get("price", {}).get("amount", {}).get("usd")
            if isinstance(item.get("floorAsk"), dict) else None
        ),
        "raw": item,
    }


def score(c, last_sale):
    now = utc_now()
    reasons = []
    points = 0

    supply = c.get("supply") or 0
    if MIN_SUPPLY <= supply <= MAX_SUPPLY:
        points += 15
        reasons.append(f"supply={supply}")

    mint_start = parse_ts(c.get("mint_start_at"))
    if mint_start and (now - mint_start).days >= MIN_AGE_DAYS:
        points += 15
        reasons.append(f"age_days={(now-mint_start).days}")

    if (c.get("mint_price_eth") is not None and
            c["mint_price_eth"] <= MAX_FREE_MINT_ETH):
        points += 15
        reasons.append("free_mint")

    # "Not yet sold" is now a first-class state. It is stored, not discarded.
    if c.get("sold_out_at"):
        points += 15
        reasons.append("sold_out")
    else:
        reasons.append("not_yet_sold")

    if (c.get("ath_floor_usd") or 0) >= MIN_ATH_FLOOR_USD:
        points += 15
        reasons.append(f"ath_floor=${c['ath_floor_usd']}")

    if (c.get("max_mint_per_wallet") or 0) >= MIN_MAX_MINT:
        points += 10
        reasons.append(f"max_mint={c['max_mint_per_wallet']}")

    # ONLY activity check: most recent actual sale timestamp + USD value.
    if last_sale:
        last_sale_at = parse_ts(last_sale.get("timestamp") or last_sale.get("createdAt"))
        last_sale_usd = extract_price_usd(last_sale)
        if last_sale_at:
            reasons.append(f"last_sale_at={iso(last_sale_at)}")
        if last_sale_usd is not None:
            reasons.append(f"last_sale_usd=${float(last_sale_usd):,.2f}")
        if last_sale_at and last_sale_usd is not None:
            points += 10

    return min(points, 100), reasons


def notify(text):
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return
    requests.post(
        f"https://api.telegram.org/bot{token}/sendMessage",
        json={"chat_id": chat_id, "text": text},
        timeout=20,
    )


def save(c, raw):
    with sqlite3.connect(DB_PATH) as db:
        old = db.execute(
            "SELECT alerted_at FROM collections WHERE chain=? AND contract=?",
            ("ethereum", c["contract"])
        ).fetchone()

        db.execute("""
        INSERT INTO collections (
            chain, contract, name, slug, supply, mint_price_eth,
            mint_start_at, last_mint_at, sold_out_at, max_mint_per_wallet,
            ath_floor_usd, current_floor_usd, last_sale_at,
            last_sale_price_eth, last_sale_price_usd, last_sale_token_id,
            sales_24h, volume_24h_eth, holder_count, score, reasons,
            source_json, first_seen_at, last_seen_at, alerted_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(chain, contract) DO UPDATE SET
            name=excluded.name, slug=excluded.slug, supply=excluded.supply,
            mint_price_eth=excluded.mint_price_eth,
            mint_start_at=excluded.mint_start_at, last_mint_at=excluded.last_mint_at,
            sold_out_at=excluded.sold_out_at,
            max_mint_per_wallet=excluded.max_mint_per_wallet,
            ath_floor_usd=excluded.ath_floor_usd,
            current_floor_usd=excluded.current_floor_usd,
            last_sale_at=excluded.last_sale_at,
            last_sale_price_eth=excluded.last_sale_price_eth,
            last_sale_price_usd=excluded.last_sale_price_usd,
            last_sale_token_id=excluded.last_sale_token_id,
            sales_24h=excluded.sales_24h,
            volume_24h_eth=excluded.volume_24h_eth,
            holder_count=excluded.holder_count, score=excluded.score,
            reasons=excluded.reasons, source_json=excluded.source_json,
            last_seen_at=excluded.last_seen_at,
            alerted_at=excluded.alerted_at
        """, (
            "ethereum", c["contract"], c.get("name"), c.get("slug"),
            c.get("supply"), c.get("mint_price_eth"),
            c.get("mint_start_at"), c.get("last_mint_at"), c.get("sold_out_at"),
            c.get("max_mint_per_wallet"), c.get("ath_floor_usd"),
            c.get("current_floor_usd"), c.get("last_sale_at"),
            c.get("last_sale_price_eth"), c.get("last_sale_price_usd"),
            c.get("last_sale_token_id"), c.get("sales_24h", 0),
            c.get("volume_24h_eth", 0), c.get("holder_count"), c.get("score"),
            json.dumps(c.get("reasons", [])), json.dumps(raw),
            iso(utc_now()), iso(utc_now()),
            old[0] if old else None
        ))

        # Alert only on a newly qualifying record.
        if c.get("score", 0) >= ALERT_SCORE and not (old and old[0]):
            db.execute(
                "UPDATE collections SET alerted_at=? WHERE chain=? AND contract=?",
                (iso(utc_now()), "ethereum", c["contract"])
            )
            return True
    return False


def scan_contract(contract):
    raw = collection_snapshot(contract)
    c = normalize_collection(raw)

    latest = last_sale_for_collection(contract)
    latest_ts = parse_ts(latest.get("timestamp") or latest.get("createdAt")) if latest else None
    latest_usd = extract_price_usd(latest) if latest else None

    c.update({
        "contract": contract,
        # These are intentionally nullable until the discovery adapter proves
        # them from mint/contract history. Never guess these values.
        "mint_price_eth": None,
        "mint_start_at": None,
        "last_mint_at": None,
        "sold_out_at": None,
        "max_mint_per_wallet": None,
        "ath_floor_usd": None,
        "current_floor_usd": c.get("floor_usd"),

        # Activity = ONLY the latest actual sale.
        "last_sale_at": iso(latest_ts) if latest_ts else None,
        "last_sale_price_eth": extract_price_eth(latest) if latest else None,
        "last_sale_price_usd": latest_usd,
        "last_sale_token_id": (
            latest.get("token", {}).get("tokenId") if latest else None
        ),

        # Removed: sales_24h and volume_24h are no longer used.
        "sales_24h": None,
        "volume_24h_eth": None,
    })

    c["score"], c["reasons"] = score(c, latest)
    alerted = save(c, raw)
    return c, alerted


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--contract", action="append",
                    help="Ethereum NFT contract. Repeat for multiple contracts.")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=int, default=300)
    args = ap.parse_args()

    init_db()

    if not args.contract:
        print("Provide --contract 0x... . Discovery is intentionally separated from scoring.")
        return

    while True:
        for contract in args.contract:
            try:
                c, alerted = scan_contract(contract)
                max_wallet = c.get("max_mint_per_wallet") or 0
                hypothetical = max_wallet * (c.get("ath_floor_usd") or 0)
                msg = (
                    f"NFT Opportunity\n"
                    f"{c.get('name') or contract}\n"
                    f"Score: {c['score']}/100\n"
                    f"Supply: {c.get('supply')}\n"
                    f"Last sale: {c.get('last_sale_price_eth')} ETH "
                    f"(${c.get('last_sale_price_usd')}) at {c.get('last_sale_at')}\n"
                    f"Status: {'SOLD OUT' if c.get('sold_out_at') else 'NOT YET SOLD OUT'}\n"
                    f"ATH floor: ${c.get('ath_floor_usd')}\n"
                    f"Hypothetical max-wallet ATH: ${hypothetical:,.0f}\n"
                    f"Reasons: {', '.join(c.get('reasons', []))}"
                )
                print(msg + "\n")
                if alerted:
                    notify(msg)
            except Exception as e:
                print(f"{contract}: ERROR: {e}")

        if args.once:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
