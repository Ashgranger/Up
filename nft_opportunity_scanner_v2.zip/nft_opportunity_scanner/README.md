# NFT Opportunity Scanner

This version scans and **saves Ethereum NFT collection records even when they are not yet sold out**.

## Activity check — intentionally simplified

Activity is **ONLY**:
1. the timestamp of the most recent actual sale;
2. the USD value of that most recent sale.

There is **no 24h sales count, 48h window, or rolling volume requirement**.

Reservoir's Sales endpoint supports sorting by sale time, so the scanner requests the latest sale and saves its timestamp and USD price. citeturn0search0

## What is saved

Every discovered collection is stored in SQLite, including:

- contract
- name / slug
- supply
- mint price when proven
- mint start / last mint
- sold-out timestamp, if sold out
- max mint per wallet when proven
- ATH floor when available
- current floor
- **last sale timestamp**
- **last sale USD value**
- last sale ETH value
- last sale token ID
- score
- reasons
- complete source JSON
- first seen / last seen timestamps

Collections are **not removed when they are not sold out**. `sold_out_at = NULL` means **not yet sold out**.

## Finding all Ethereum NFT contracts

The production discovery layer should paginate Reservoir's collection catalog and persist every Ethereum collection, then run the scoring/activity check against each contract. Reservoir's Collections API supports pagination/continuation and can return collection metadata/statistics; its Ethereum API covers Ethereum NFT data. citeturn0search1turn0search2

For new/recent activity, Reservoir also exposes collection activity and sale event streams. citeturn0search5turn0search3

## Run

```bash
export RESERVOIR_API_KEY="YOUR_KEY"
python scanner.py --contract 0xYOUR_CONTRACT --once
```

The SQLite database is `opportunities.db`.

## Next production adapter

To truly enumerate **all Ethereum NFT contracts**, add a paginator around the Reservoir Collections endpoint and/or an on-chain contract discovery indexer. The database should keep every discovered collection, including those that have not sold out yet.

Mint price, wallet mint limit, original mint dates, and ATH need evidence from contract/indexer data; the scanner deliberately leaves them NULL rather than guessing.
